#!/bin/bash

timer_start=`date "+%Y-%m-%d %H:%M:%S"`
echo "start_time: $timer_start"

echo 'Numerical experiments start'
cd ~/research-paper/paper15/computation/code/
echo 'Numerical experiment 1 - connectivity 5'
gfortran Numer-Exper1-NN-5-CSAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper1-NN-5-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper1-NN-5-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 1 - connectivity 7'
gfortran Numer-Exper1-NN-7-CSAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper1-NN-7-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper1-NN-7-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 1 - connectivity 9'
gfortran Numer-Exper1-NN-9-CSAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper1-NN-9-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper1-NN-9-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 2 - cavity spacing 5.1'
gfortran Numer-Exper2-CP-51-CSAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper2-CP-51-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper2-CP-51-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 2 - cavity spacing 5.3'
gfortran Numer-Exper2-CP-53-CSAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper2-CP-53-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper2-CP-53-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 2 - cavity spacing 5.5'
gfortran Numer-Exper2-CP-55-CSAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper2-CP-55-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper2-CP-55-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 2 - cavity spacing 5.7'
gfortran Numer-Exper2-CP-57-CSAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper2-CP-57-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper2-CP-57-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 2 - cavity spacing 5.9'
gfortran Numer-Exper2-CP-59-CSAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper2-CP-59-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper2-CP-59-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 3 - Nk 40'
gfortran Numer-Exper3-Nk-40-CSAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper3-Nk-40-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper3-Nk-40-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 3 - Nk 45'
gfortran Numer-Exper3-Nk-45-CSAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper3-Nk-45-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper3-Nk-45-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 3 - Nk 50'
gfortran Numer-Exper3-Nk-50-CSAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper3-Nk-50-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper3-Nk-50-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 3 - Nk 55'
gfortran Numer-Exper3-Nk-55-CSAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper3-Nk-55-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper3-Nk-55-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 3 - Mkl 10'
gfortran Numer-Exper3-Mkl-10-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper3-Mkl-10-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 3 - Mkl 20'
gfortran Numer-Exper3-Mkl-20-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper3-Mkl-20-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 3 - Mkl 30'
gfortran Numer-Exper3-Mkl-30-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper3-Mkl-30-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 3 - Mkl 40'
gfortran Numer-Exper3-Mkl-40-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
gfortran Numer-Exper3-Mkl-40-GCVM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 4 - Stability - connectivity 5'
gfortran Numer-Exper4-Stability-NN-5-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 4 - Stability - connectivity 7'
gfortran Numer-Exper4-Stability-NN-7-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiment 4 - Stability - connectivity 9'
gfortran Numer-Exper4-Stability-NN-9-ASAM.f90 -L/usr/local/lib -llapack -lrefblas -o case
./case
echo 'Numerical experiments finish'

cd ~/research-paper/paper15/computation/plot/
gnuplot Numer-Exper-1.gnuplot
cp Numer-Exper-1.pdf /home/lin/research-paper/paper15/CG-revision/manuscript/fig4.pdf
gnuplot Numer-Exper-2.gnuplot
cp Numer-Exper-2.pdf /home/lin/research-paper/paper15/CG-revision/manuscript/fig5.pdf
gnuplot Numer-Exper-2-time-accuracy.gnuplot
cp Numer-Exper-2-time-accuracy.pdf /home/lin/research-paper/paper15/CG-revision/manuscript/fig6.pdf
gnuplot Numer-Exper-4.gnuplot
cp Numer-Exper-4.pdf /home/lin/research-paper/paper15/CG-revision/manuscript/fig7.pdf

timer_end=`date "+%Y-%m-%d %H:%M:%S"`
echo "end_time: $timer_end"
start_seconds=$(date --date="$timer_start" +%s);
end_seconds=$(date --date="$timer_end" +%s);
echo "consuming_time: "$((end_seconds-start_seconds))"s"
